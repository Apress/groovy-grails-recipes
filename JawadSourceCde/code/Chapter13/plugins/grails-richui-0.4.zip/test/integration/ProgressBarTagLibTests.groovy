class ProgressBarTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}