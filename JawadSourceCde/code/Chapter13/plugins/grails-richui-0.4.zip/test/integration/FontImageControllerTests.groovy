class FontImageControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}