import de.andreasschmitt.richui.taglib.renderer.RatingRenderer

class RatingTagLibTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
