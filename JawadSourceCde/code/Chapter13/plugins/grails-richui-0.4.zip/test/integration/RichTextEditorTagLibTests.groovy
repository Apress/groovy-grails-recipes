class RichTextEditorTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
