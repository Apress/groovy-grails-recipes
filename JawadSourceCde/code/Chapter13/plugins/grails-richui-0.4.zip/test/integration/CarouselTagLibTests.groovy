class CarouselTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
